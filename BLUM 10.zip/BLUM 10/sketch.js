let vid;
function setup() {
  noCanvas();

  vid = createVideo(
    ['assets/Earth.mp4', 'assets/Earth.ogv', 'assets/Earth.webm'],
    vidLoad
  );

  vid.size(100, 100);
}

function vidLoad() {
  vid.loop();
  vid.volume(2);
}